//respuesta 1
function verificarRespuesta1() {
    const respuesta = document.getElementById("respuesta").value.toLowerCase();
    const resultadoDiv = document.getElementById("result");

    if (respuesta === "180 km") {
        resultadoDiv.textContent = "¡Correcto!";
        resultadoDiv.style.color = "green";
    }
    else if (respuesta === "180 km ") {
        resultadoDiv.textContent = "¡Correcto!";
        resultadoDiv.style.color = "green";
    } 
    else if (respuesta === "180km") {
        resultadoDiv.textContent = "¡Correcto!";
        resultadoDiv.style.color = "green";
    } 
    else if (respuesta === "180km ") {
        resultadoDiv.textContent = "¡Correcto!";
        resultadoDiv.style.color = "green";
    } 
    else if (respuesta === "180") {
        resultadoDiv.textContent = "¡Correcto! pero Recuerda que su unidad de medida es km";
        resultadoDiv.style.color = "green";
    }
    else if (respuesta === "180 ") {
        resultadoDiv.textContent = "¡Correcto! pero Recuerda que su unidad de medida es km";
        resultadoDiv.style.color = "green";
    }
    else {
        resultadoDiv.textContent = "Incorrecto.";
        resultadoDiv.style.color = "red";
    }
}
//respuesta 2
function verificarRespuesta2() {
    const respuesta2 = document.getElementById("respuesta2").value.toLowerCase();
    const resultadoDiv2 = document.getElementById("result2");

    if (respuesta2 === "60 km/h") {
        resultadoDiv2.textContent = "¡Correcto!";
        resultadoDiv2.style.color = "green";
    } 
    else if (respuesta2 === "60 km/h ") {
        resultadoDiv2.textContent = "¡Correcto!";
        resultadoDiv2.style.color = "green";
    }
    else if (respuesta2 === "60km/h") {
        resultadoDiv2.textContent = "¡Correcto!";
        resultadoDiv2.style.color = "green";
    } 
    else if (respuesta2 === "60km/h ") {
        resultadoDiv2.textContent = "¡Correcto!";
        resultadoDiv2.style.color = "green";
    } 
    else if (respuesta2 === "60") {
        resultadoDiv2.textContent = "¡Correcto! pero  Recuerda que su unidad de medida es km/h";
        resultadoDiv2.style.color = "green";
    }
    else if (respuesta2 === "60 ") {
        resultadoDiv2.textContent = "¡Correcto! pero  Recuerda que su unidad de medida es km/h";
        resultadoDiv2.style.color = "green";
    }
    else {
        resultadoDiv2.textContent = "Incorrecto.";
        resultadoDiv2.style.color = "red";
    }
}
//respuesta 3
function verificarRespuesta3() {
    const respuesta3 = document.getElementById("respuesta3").value.toLowerCase();
    const resultadoDiv3 = document.getElementById("result3");

    if (respuesta3 === "1800 m") {
        resultadoDiv3.textContent = "¡Correcto!";
        resultadoDiv3.style.color = "green";
    } 
    else if (respuesta3 === "1800 m ") {
        resultadoDiv3.textContent = "¡Correcto!";
        resultadoDiv3.style.color = "green";
    }
    else if (respuesta3 === "1800m") {
        resultadoDiv3.textContent = "¡Correcto!";
        resultadoDiv3.style.color = "green";
    }
    else if (respuesta3 === "1800m ") {
        resultadoDiv3.textContent = "¡Correcto!";
        resultadoDiv3.style.color = "green";
    }
    else if (respuesta3 === "1800") {
        resultadoDiv3.textContent = "¡Correcto! pero Recuerda que su unidad de medida es m";
        resultadoDiv3.style.color = "green";
    }
    else if (respuesta3 === "1800 ") {
        resultadoDiv3.textContent = "¡Correcto! pero Recuerda que su unidad de medida es m";
        resultadoDiv3.style.color = "green";
    }
    else {
        resultadoDiv3.textContent = "Incorrecto.";
        resultadoDiv3.style.color = "red";
    }
}
//respuesta 4
function verificarRespuesta4() {
    const respuesta4 = document.getElementById("respuesta4").value.toLowerCase();
    const resultadoDiv4 = document.getElementById("result4");

    if (respuesta4 === "392 j") {
        resultadoDiv4.textContent = "¡Correcto!";
        resultadoDiv4.style.color = "green";
    } 
    else if (respuesta4 === "392 j ") {
        resultadoDiv4.textContent = "¡Correcto!";
        resultadoDiv4.style.color = "green";
    } 
    else if (respuesta4 === "392j") {
        resultadoDiv4.textContent = "¡Correcto!";
        resultadoDiv4.style.color = "green";
    }
    else if (respuesta4 === "392j ") {
        resultadoDiv4.textContent = "¡Correcto!";
        resultadoDiv4.style.color = "green";
    }
    else if (respuesta4 === "392") {
        resultadoDiv4.textContent = "¡Correcto! pero Recuerda que su unidad de medida es j";
        resultadoDiv4.style.color = "green";
    }
    else if (respuesta4 === "392 ") {
        resultadoDiv4.textContent = "¡Correcto! pero Recuerda que su unidad de medida es j";
        resultadoDiv4.style.color = "green";
    }
    else {
        resultadoDiv4.textContent = "Incorrecto.";
        resultadoDiv4.style.color = "red";
    }
}
//respuesta 5
function verificarRespuesta5() {
    const respuesta5 = document.getElementById("respuesta5").value.toLowerCase();
    const resultadoDiv5 = document.getElementById("result5");

    if (respuesta5 === "39200 j") {
        resultadoDiv5.textContent = "¡Correcto!";
        resultadoDiv5.style.color = "green";
    }
    else if (respuesta5 === "39200 j ") {
        resultadoDiv5.textContent = "¡Correcto!";
        resultadoDiv5.style.color = "green";
    }
    else if (respuesta5 === "39200j") {
        resultadoDiv5.textContent = "¡Correcto!";
        resultadoDiv5.style.color = "green";
    }
    else if (respuesta5 === "39200j ") {
        resultadoDiv5.textContent = "¡Correcto!";
        resultadoDiv5.style.color = "green";
    }
    else if (respuesta5 === "39200") {
        resultadoDiv5.textContent = "¡Correcto! pero Recuerda que su unidad de medida es j";
        resultadoDiv5.style.color = "green";
    }
    else if (respuesta5 === "39200 ") {
        resultadoDiv5.textContent = "¡Correcto! pero Recuerda que su unidad de medida es j";
        resultadoDiv5.style.color = "green";
    }
    else {
        resultadoDiv5.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv5.style.color = "red";
    }
}
//respuesta 6
function verificarRespuesta6() {
    const respuesta6 = document.getElementById("respuesta6").value.toLowerCase();
    const resultadoDiv6 = document.getElementById("result6");

    if (respuesta6 === "200000 j") {
        resultadoDiv6.textContent = "¡Correcto!";
        resultadoDiv6.style.color = "green";
    }
    else if (respuesta6 === "200000 j ") {
        resultadoDiv6.textContent = "¡Correcto!";
        resultadoDiv6.style.color = "green";
    }
    else if (respuesta6 === "200000") {
        resultadoDiv6.textContent = "¡Correcto! pero Recuerda que su unidad de medida es j";
        resultadoDiv6.style.color = "green";
    }
    else if (respuesta6 === "200000 ") {
        resultadoDiv6.textContent = "¡Correcto! pero Recuerda que su unidad de medida es j";
        resultadoDiv6.style.color = "green";
    }
    else {
        resultadoDiv6.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv6.style.color = "red";
    }
}
//respuesta 7
function verificarRespuesta7() {
    const respuesta7 = document.getElementById("respuesta7").value.toLowerCase();
    const resultadoDiv7 = document.getElementById("result7");

    if (respuesta7 === "490 j") {
        resultadoDiv7.textContent = "¡Correcto!";
        resultadoDiv7.style.color = "green";
    } 
    else if (respuesta7 === "490 j ") {
        resultadoDiv7.textContent = "¡Correcto!";
        resultadoDiv7.style.color = "green";
    } 
    else if (respuesta7 === "490j") {
        resultadoDiv7.textContent = "¡Correcto!";
        resultadoDiv7.style.color = "green";
    }
    else if (respuesta7 === "490j ") {
        resultadoDiv7.textContent = "¡Correcto!";
        resultadoDiv7.style.color = "green";
    }
    else if (respuesta7 === "490") {
        resultadoDiv7.textContent = "¡Correcto! pero pero Recuerda que su unidad de medida es j";
        resultadoDiv7.style.color = "green";
    }
    else if (respuesta7 === "490 ") {
        resultadoDiv7.textContent = "¡Correcto! pero pero Recuerda que su unidad de medida es j";
        resultadoDiv7.style.color = "green";
    }
    else {
        resultadoDiv7.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv7.style.color = "red";
    }
}
//resultado 8
function verificarRespuesta8() {
    const respuesta8 = document.getElementById("respuesta8").value.toLowerCase();
    const resultadoDiv8 = document.getElementById("result8");

    if (respuesta8 === "176.4 j") {
        resultadoDiv8.textContent = "¡Correcto!";
        resultadoDiv8.style.color = "green";
    }
    else if (respuesta8 === "176.4 j ") {
        resultadoDiv8.textContent = "¡Correcto!";
        resultadoDiv8.style.color = "green";
    }
    else if (respuesta8 === "176.4") {
        resultadoDiv8.textContent = "¡Correcto! pero pero Recuerda que su unidad de medida es j";
        resultadoDiv8.style.color = "green";
    }
    else if (respuesta8 === "176.4 ") {
        resultadoDiv8.textContent = "¡Correcto! pero pero Recuerda que su unidad de medida es j";
        resultadoDiv8.style.color = "green";
    }
    else {
        resultadoDiv8.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv8.style.color = "red";
    }
}
//resultado 9
function verificarRespuesta9() {
    const respuesta9 = document.getElementById("respuesta9").value.toLowerCase();
    const resultadoDiv9 = document.getElementById("result9");

    if (respuesta9 === "5000 m") {
        resultadoDiv9.textContent = "¡Correcto!";
        resultadoDiv9.style.color = "green";
    } 
    else if (respuesta9 === "5000 m ") {
        resultadoDiv9.textContent = "¡Correcto!";
        resultadoDiv9.style.color = "green";
    }
    else if (respuesta9 === "5000") {
        resultadoDiv9.textContent = "¡Correcto! pero Recuerda que su unidad de medida es m";
        resultadoDiv9.style.color = "green";
    }
    else if (respuesta9 === "5000 ") {
        resultadoDiv9.textContent = "¡Correcto! pero Recuerda que su unidad de medida es m";
        resultadoDiv9.style.color = "green";
    }
    else {
        resultadoDiv9.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv9.style.color = "red";
    }
}
//resultado 10
function verificarRespuesta10() {
    const respuesta10 = document.getElementById("respuesta10").value.toLowerCase();
    const resultadoDiv10 = document.getElementById("result10");

    if (respuesta10 === "1.2 kg") {
        resultadoDiv10.textContent = "¡Correcto!";
        resultadoDiv10.style.color = "green";
    } 
    else if (respuesta10 === "1.2 kg ") {
        resultadoDiv10.textContent = "¡Correcto!";
        resultadoDiv10.style.color = "green";
    } 
    else if (respuesta10 === "1.2kg") {
        resultadoDiv10.textContent = "¡Correcto!";
        resultadoDiv10.style.color = "green";
    }
    else if (respuesta10 === "1.2kg " ) {
        resultadoDiv10.textContent = "¡Correcto!";
        resultadoDiv10.style.color = "green";
    }
    else if (respuesta10 === "1.2") {
        resultadoDiv10.textContent = "¡Correcto! pero Recuerda que su unidad de medida son kg";
        resultadoDiv10.style.color = "green";
    }
    else if (respuesta10 === "1.2 ") {
        resultadoDiv10.textContent = "¡Correcto! pero Recuerda que su unidad de medida son kg";
        resultadoDiv10.style.color = "green";
    }
    else {
        resultadoDiv10.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv10.style.color = "red";
    }
}
//resultado 11
function verificarRespuesta11() {
    const respuesta11 = document.getElementById("respuesta11").value.toLowerCase();
    const resultadoDiv11 = document.getElementById("result11");

    if (respuesta11 === "10800 s" || respuesta === "10800 s") {
        resultadoDiv11.textContent = "!Correcto!";
        resultadoDiv11.style.color = "green";
    }
    else if (respuesta11 === "10800 s " ) {
        resultadoDiv11.textContent = "!Correcto!";
        resultadoDiv11.style.color = "green";
    }
    else if (respuesta11 === "10800s" ) {
        resultadoDiv11.textContent = "!Correcto!";
        resultadoDiv11.style.color = "green";
    }
    else if (respuesta11 === "10800s " ) {
        resultadoDiv11.textContent = "!Correcto!";
        resultadoDiv11.style.color = "green";
    }
    else if (respuesta11 === "10800" ) {
        resultadoDiv11.textContent = "!Correcto!, pero recuerda que si unidad de medida es s";
        resultadoDiv11.style.color = "green";
    }
    else if (respuesta11 === "10800 " ) {
        resultadoDiv11.textContent = "!Correcto!, pero recuerda que si unidad de medida es s";
        resultadoDiv11.style.color = "green";
    }
    else {
        resultadoDiv11.textContent = "Incorrecto. Intenta de nuevo.";
        resultadoDiv11.style.color = "red";
    }
}
//resultado 12
function verificarRespuesta12() {
    const respuesta12 = document.getElementById("respuesta12").value.toLowerCase();
    const resultadoDiv12 = document.getElementById("result12");

    if (respuesta12 === "9 km/h" ) {
        resultadoDiv12.textContent = "!Correcto!";
        resultadoDiv12.style.color = "green";
    }
    else if (respuesta12 === "9 km/h " ) {
        resultadoDiv12.textContent = "!Correcto!";
        resultadoDiv12.style.color = "green";
    }
    else if (respuesta12 === "9km/h" ) {
        resultadoDiv12.textContent = "!Correcto!";
        resultadoDiv12.style.color = "green";
    }
    else if (respuesta12 === "9km/h" ) {
        resultadoDiv12.textContent = "!Correcto!";
        resultadoDiv12.style.color = "green";
    }
    else if (respuesta12 === "9" ) {
        resultadoDiv12.textContent = "!Correcto!, pero recuerda que su unidad de medida es km/h";
        resultadoDiv12.style.color = "green";
    }
    else if (respuesta12 === "9 " ) {
        resultadoDiv12.textContent = "!Correcto!, pero recuerda que su unidad de medida es km/h";
        resultadoDiv12.style.color = "green";
    }
    else {
        resultadoDiv12.textContent = "Incorrecto. Intenta de nuevo."; 
        resultadoDiv12.style.color = "red";
    }
}
//resultado 13
function verificarRespuesta13() { 
    const respuesta13 = document.getElementById("respuesta13").value.toLowerCase();
    const resultadoDiv13 = document.getElementById("result13");

    if (respuesta13 === "-48 n" ) {
        resultadoDiv13.textContent = "!Correcto!";
        resultadoDiv13.style.color = "green";
    }
    else if (respuesta13 === "-48 n " ) {
        resultadoDiv13.textContent = "!Correcto!";
        resultadoDiv13.style.color = "green";
    }
    else if (respuesta13 === "-48n" ) {
        resultadoDiv13.textContent = "!Correcto!";
        resultadoDiv13.style.color = "green";
    }
    else if (respuesta13 === "-48n " ) {
        resultadoDiv13.textContent = "!Correcto!";
        resultadoDiv13.style.color = "green";
    }
    else if (respuesta13 === "-48" ) {
        resultadoDiv13.textContent = "!Correcto!, pero recuerda que su unidad de medida es n";
        resultadoDiv13.style.color = "green";
    }
    else if (respuesta13 === "-48 " ) {
        resultadoDiv13.textContent = "!Correcto!, pero recuerda que su unidad de medida es n";
        resultadoDiv13.style.color = "green";
    }
    else {
        resultadoDiv13.textContent = "Incorrecto. Intenta de nuevo."; 
        resultadoDiv13.style.color = "red"; 
    }
}
